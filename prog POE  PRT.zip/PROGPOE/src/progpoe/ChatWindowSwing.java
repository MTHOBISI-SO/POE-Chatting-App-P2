package progpoe;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class ChatWindowSwing extends JFrame {
    private String username;
    private String userPhone;

    private JTextField recipientPhoneField;
    private JTextArea messageArea;
    private JTextArea chatArea;
    private JButton sendButton, loadButton, logoutButton;

    private Color backgroundColor = new Color(245, 245, 245);
    private Color accentColor = new Color(0, 128, 128);
    private Color textColor = new Color(50, 50, 50);

    private static final String MESSAGE_FILE = "messages.txt";

    public ChatWindowSwing(String username, String userPhone) {
        this.username = username;
        this.userPhone = userPhone;

        setTitle("Welcome to Chat App - " + username);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 500);
        setLocationRelativeTo(null);
        getContentPane().setBackground(backgroundColor);
        setLayout(new BorderLayout());

        // Top panel with welcome label and logout button
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(backgroundColor);
        JLabel welcomeLabel = new JLabel("Welcome to Chat App - " + username);
        welcomeLabel.setFont(new Font("Aptos", Font.BOLD, 22));
        welcomeLabel.setForeground(accentColor);
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        topPanel.add(welcomeLabel, BorderLayout.WEST);

        logoutButton = new JButton("Logout");
        logoutButton.setBackground(accentColor);
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        logoutButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        logoutButton.addActionListener(e -> {
            dispose();
            // Optionally reopen login window
            SwingUtilities.invokeLater(UserLogInSwing::new);
        });
        topPanel.add(logoutButton, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);

        // Center panel for chat display
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setFont(new Font("Aptos", Font.PLAIN, 14));
        chatArea.setForeground(textColor);
        chatArea.setBackground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(chatArea);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom panel for message input and controls
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(backgroundColor);
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        inputPanel.setBackground(backgroundColor);

        recipientPhoneField = new JTextField(10);
        recipientPhoneField.setFont(new Font("Aptos", Font.PLAIN, 14));
        recipientPhoneField.setBorder(BorderFactory.createTitledBorder("Recipient Phone"));
        inputPanel.add(recipientPhoneField);

        messageArea = new JTextArea(3, 30);
        messageArea.setFont(new Font("Aptos", Font.PLAIN, 14));
        JScrollPane messageScrollPane = new JScrollPane(messageArea);
        messageScrollPane.setBorder(BorderFactory.createTitledBorder("Enter Message"));
        inputPanel.add(messageScrollPane);

        bottomPanel.add(inputPanel, BorderLayout.CENTER);

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonsPanel.setBackground(backgroundColor);

        sendButton = new JButton("Send");
        sendButton.setBackground(accentColor);
        sendButton.setForeground(Color.WHITE);
        sendButton.setFocusPainted(false);
        sendButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        sendButton.addActionListener(e -> sendMessage());
        buttonsPanel.add(sendButton);

        loadButton = new JButton("Load Messages");
        loadButton.setBackground(accentColor);
        loadButton.setForeground(Color.WHITE);
        loadButton.setFocusPainted(false);
        loadButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        loadButton.addActionListener(e -> loadMessages());
        buttonsPanel.add(loadButton);

        bottomPanel.add(buttonsPanel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void sendMessage() {
        String recipientPhone = recipientPhoneField.getText().trim();
        String messageText = messageArea.getText().trim();

        if (recipientPhone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the recipient's phone number.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (messageText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a message.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String messageId = generateRandomMessageId();
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        String messageLine = messageId + "," + timestamp + "," + username + "," + userPhone + "," + recipientPhone + "," + messageText;

        try (FileWriter fw = new FileWriter(MESSAGE_FILE, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            out.println(messageLine);
            JOptionPane.showMessageDialog(this, "Message sent successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            messageArea.setText("");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Failed to send message.", "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void loadMessages() {
        chatArea.setText("");
        try (BufferedReader br = new BufferedReader(new FileReader(MESSAGE_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Format: messageID,timestamp,senderUsername,senderPhone,recipientPhone,messageText
                String[] parts = line.split(",", 6);
                if (parts.length < 6) continue;

                String messageId = parts[0];
                String timestamp = parts[1];
                String senderUsername = parts[2];
                String senderPhone = parts[3];
                String recipientPhone = parts[4];
                String messageText = parts[5];

                // Show messages where current user is either sender or recipient
                if ((senderPhone.equals(userPhone) || recipientPhone.equals(userPhone))) {
                    String direction = senderPhone.equals(userPhone) ? "To " + recipientPhone : "From " + senderPhone;
                    chatArea.append("[" + messageId + "] " + timestamp + " " + direction + " (" + senderUsername + "): " + messageText + "\n");
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Failed to load messages.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private String generateRandomMessageId() {
        Random rand = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append(rand.nextInt(10));
        }
        return sb.toString();
    }
}
